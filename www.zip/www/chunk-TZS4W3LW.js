var r="1.2.0";export{r as a};
