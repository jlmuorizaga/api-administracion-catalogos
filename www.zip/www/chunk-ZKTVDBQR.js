var r="0.10.1";export{r as a};
