var e="0.10.0";export{e as a};
