var e="0.5.0";export{e as a};
